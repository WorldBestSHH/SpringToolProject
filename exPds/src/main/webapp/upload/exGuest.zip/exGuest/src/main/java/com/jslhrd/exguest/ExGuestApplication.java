package com.jslhrd.exguest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExGuestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExGuestApplication.class, args);
	}

}
