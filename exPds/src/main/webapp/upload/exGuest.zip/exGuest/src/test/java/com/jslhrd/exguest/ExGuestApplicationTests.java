package com.jslhrd.exguest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExGuestApplicationTests {

	@Test
	void contextLoads() {
	}

}
